import { NavItem, PracticeArea, FAQItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: { en: 'Home', ar: 'الرئيسية' }, href: '#home' },
  { label: { en: 'About', ar: 'من نحن' }, href: '#about' },
  { label: { en: 'Practice Areas', ar: 'الاختصاصات' }, href: '#practice-areas' },
  { label: { en: 'Why Us', ar: 'لماذا نحن' }, href: '#why-us' },
  { label: { en: 'FAQ', ar: 'الأسئلة' }, href: '#faq' },
  { label: { en: 'Contact', ar: 'تواصل' }, href: '#contact' },
];

export const PRACTICE_AREAS: PracticeArea[] = [
  {
    id: 'civil',
    title: { en: 'Civil Law', ar: 'القانون المدني' },
    icon: 'Scale',
    description: {
      en: 'Comprehensive civil litigation and dispute resolution services. We represent clients in contract disputes, property matters, and personal injury claims.',
      ar: 'خدمات التقاضي المدني الشاملة وحل النزاعات. نمثل العملاء في نزاعات العقود، القضايا العقارية، ودعاوى الإصابات الشخصية.'
    },
    keyServices: {
      en: ['Contract Disputes', 'Property Litigation', 'Tort Claims', 'Civil Rights'],
      ar: ['نزاعات العقود', 'التقاضي العقاري', 'دعاوى الضرر', 'الحقوق المدنية']
    }
  },
  {
    id: 'commercial',
    title: { en: 'Commercial & Corporate', ar: 'القانون التجاري والشركات' },
    icon: 'Building2',
    description: {
      en: 'Expert guidance for businesses at every stage. From company formation to complex M&A transactions and corporate governance.',
      ar: 'إرشاد متخصص للشركات في كل مرحلة. من تأسيس الشركات إلى معاملات الاندماج والاستحواذ المعقدة وحوكمة الشركات.'
    },
    keyServices: {
      en: ['Company Formation', 'Corporate Governance', 'M&A Transactions', 'Commercial Contracts'],
      ar: ['تأسيس الشركات', 'حوكمة الشركات', 'عمليات الاندماج والاستحواذ', 'العقود التجارية']
    }
  },
  {
    id: 'arbitration',
    title: { en: 'Arbitration & Mediation', ar: 'التحكيم والوساطة' },
    icon: 'Handshake',
    description: {
      en: 'Alternative dispute resolution excellence. We represent clients in arbitration proceedings and facilitate mediation for efficient resolution.',
      ar: 'تميز في حل النزاعات البديل. نمثل العملاء في إجراءات التحكيم ونسهل الوساطة للحل الفعال.'
    },
    keyServices: {
      en: ['Commercial Arbitration', 'International Arbitration', 'Mediation Services', 'ADR Strategy'],
      ar: ['التحكيم التجاري', 'التحكيم الدولي', 'خدمات الوساطة', 'استراتيجية حل النزاعات البديلة']
    }
  },
  {
    id: 'criminal',
    title: { en: 'Criminal Defense', ar: 'الدفاع الجنائي' },
    icon: 'ShieldAlert',
    description: {
      en: 'Vigorous defense of your rights and freedom. We provide strategic criminal defense representation with meticulous preparation.',
      ar: 'دفاع قوي عن حقوقكم وحريتكم. نقدم تمثيلاً دفاعياً جنائياً استراتيجياً بإعداد دقيق.'
    },
    keyServices: {
      en: ['Criminal Defense', 'White Collar Crime', 'Appeals', 'Bail Proceedings'],
      ar: ['الدفاع الجنائي', 'جرائم ذوي الياقات البيضاء', 'الاستئناف', 'إجراءات الكفالة']
    }
  },
  {
    id: 'contracts',
    title: { en: 'Contract Drafting', ar: 'صياغة العقود' },
    icon: 'FileText',
    description: {
      en: 'Precision in every word. Our contract services ensure your agreements are legally sound and protect your interests.',
      ar: 'دقة في كل كلمة. تضمن خدماتنا التعاقدية أن اتفاقياتكم سليمة قانونياً وتحمي مصالحكم.'
    },
    keyServices: {
      en: ['Contract Drafting', 'Agreement Review', 'Negotiation Support', 'Risk Assessment'],
      ar: ['صياغة العقود', 'مراجعة الاتفاقيات', 'دعم المفاوضات', 'تقييم المخاطر']
    }
  },
  {
    id: 'consultation',
    title: { en: 'Legal Consultation', ar: 'الاستشارات القانونية' },
    icon: 'Briefcase',
    description: {
      en: 'Strategic legal advice for informed decision-making across all practice areas and complex legal landscapes.',
      ar: 'مشورة قانونية استراتيجية لاتخاذ قرارات مستنيرة عبر جميع مجالات الممارسة والمشاهد القانونية المعقدة.'
    },
    keyServices: {
      en: ['Legal Opinions', 'Risk Analysis', 'Compliance Review', 'Strategic Planning'],
      ar: ['الآراء القانونية', 'تحليل المخاطر', 'مراجعة الامتثال', 'التخطيط الاستراتيجي']
    }
  }
];

export const FAQS: FAQItem[] = [
  {
    question: { en: 'What areas of law do you specialize in?', ar: 'ما هي مجالات القانون التي تتخصصون فيها؟' },
    answer: { 
      en: 'Abu Sweilem & Partners provides comprehensive legal services across civil law, commercial and corporate law, arbitration and mediation, criminal defense, contract drafting, and legal consultation.',
      ar: 'يقدم مكتب أبو سويلم وشركاؤه خدمات قانونية شاملة في القانون المدني، القانون التجاري وقانون الشركات، التحكيم والوساطة، الدفاع الجنائي، صياغة العقود، والاستشارات القانونية.'
    }
  },
  {
    question: { en: 'How do I schedule a consultation?', ar: 'كيف أحجز استشارة؟' },
    answer: {
      en: 'You can schedule a consultation through our website contact form, by calling our office directly, or via email. We offer initial consultations to understand your legal needs.',
      ar: 'يمكنك حجز استشارة من خلال نموذج الاتصال على موقعنا، أو بالاتصال بمكتبنا مباشرة، أو عبر البريد الإلكتروني. نحن نقدم استشارات أولية لفهم احتياجاتك القانونية.'
    }
  },
  {
    question: { en: 'Do you provide services in both Arabic and English?', ar: 'هل تقدمون خدمات بالعربية والإنجليزية؟' },
    answer: {
      en: 'Yes, we are fully bilingual. All our attorneys and staff are fluent in both Arabic and English, ensuring seamless communication.',
      ar: 'نعم، نحن ثنائيو اللغة تماماً. جميع محامينا وموظفينا يتقنون اللغتين العربية والإنجليزية، مما يضمن تواصلاً سلساً.'
    }
  },
  {
    question: { en: 'What are your fee structures?', ar: 'ما هي هياكل الرسوم لديكم؟' },
    answer: {
      en: 'Our fee structures vary depending on the nature and complexity of your case. We offer hourly rates, flat fees, and contingency arrangements where appropriate.',
      ar: 'تختلف هياكل الرسوم لدينا حسب طبيعة قضيتك وتعقيدها. نحن نقدم أسعاراً بالساعة، ورسوماً ثابتة، وترتيبات طوارئ حيثما كان ذلك مناسباً.'
    }
  }
];
