import React from 'react';
import { useLanguage } from '../LanguageContext';
import { motion } from 'motion/react';
import { MapPin, Phone, Mail, MessageCircle, Clock } from 'lucide-react';

export const Contact = () => {
  const { t } = useLanguage();

  return (
    <section id="contact" className="py-24 bg-cream-soft">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif-en text-4xl md:text-5xl font-bold text-brand-burgundy mb-4">
            {t({ en: 'GET IN TOUCH', ar: 'تواصل معنا' })}
          </h2>
          <div className="w-20 h-1 bg-accent-bronze mx-auto mb-6" />
          <p className="text-text-secondary text-lg">
            {t({ en: 'Ready to discuss your legal matter? Schedule your consultation today.', ar: 'مستعد لمناقشة قضيتك؟ احجز استشارتك اليوم.' })}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Form */}
          <div className="lg:col-span-3 bg-white p-8 md:p-12 rounded-3xl shadow-xl">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-brand-burgundy uppercase tracking-wider">
                    {t({ en: 'Full Name', ar: 'الاسم الكامل' })} *
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full bg-cream-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-burgundy outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-brand-burgundy uppercase tracking-wider">
                    {t({ en: 'Email Address', ar: 'البريد الإلكتروني' })} *
                  </label>
                  <input
                    type="email"
                    required
                    className="w-full bg-cream-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-burgundy outline-none transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-brand-burgundy uppercase tracking-wider">
                    {t({ en: 'Phone Number', ar: 'رقم الهاتف' })} *
                  </label>
                  <input
                    type="tel"
                    required
                    className="w-full bg-cream-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-burgundy outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-brand-burgundy uppercase tracking-wider">
                    {t({ en: 'Legal Category', ar: 'نوع القضية' })}
                  </label>
                  <select className="w-full bg-cream-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-burgundy outline-none transition-all appearance-none">
                    <option>{t({ en: 'Civil Law', ar: 'القانون المدني' })}</option>
                    <option>{t({ en: 'Commercial', ar: 'تجاري' })}</option>
                    <option>{t({ en: 'Criminal', ar: 'جنائي' })}</option>
                    <option>{t({ en: 'Other', ar: 'أخرى' })}</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-brand-burgundy uppercase tracking-wider">
                  {t({ en: 'Message', ar: 'الرسالة' })} *
                </label>
                <textarea
                  rows={5}
                  required
                  className="w-full bg-cream-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-burgundy outline-none transition-all"
                ></textarea>
              </div>

              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <input type="checkbox" className="w-5 h-5 rounded border-brand-burgundy text-brand-burgundy focus:ring-brand-burgundy" />
                <span className="text-sm text-text-muted">
                  {t({ en: 'I agree to the privacy policy and terms', ar: 'أوافق على سياسة الخصوصية والشروط' })}
                </span>
              </div>

              <button className="w-full bg-brand-burgundy text-white py-4 rounded-xl font-bold text-lg hover:bg-accent-bronze transition-all shadow-lg">
                {t({ en: 'Book Consultation Now', ar: 'احجز استشارة الآن' })}
              </button>
            </form>
          </div>

          {/* Info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-brand-burgundy text-white p-10 rounded-3xl shadow-xl space-y-8">
              <div className="flex items-start space-x-4 rtl:space-x-reverse">
                <div className="bg-white/10 p-3 rounded-lg">
                  <MapPin size={24} className="text-accent-bronze" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 uppercase tracking-widest">{t({ en: 'Office Address', ar: 'عنوان المكتب' })}</h4>
                  <p className="text-white/80 leading-relaxed">
                    Abu Sweilem & Partners<br />
                    Amman, Jordan<br />
                    Abdali District, Building 45
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4 rtl:space-x-reverse">
                <div className="bg-white/10 p-3 rounded-lg">
                  <Phone size={24} className="text-accent-bronze" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 uppercase tracking-widest">{t({ en: 'Phone', ar: 'الهاتف' })}</h4>
                  <p className="text-white/80">+962 6 123 4567</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 rtl:space-x-reverse">
                <div className="bg-white/10 p-3 rounded-lg">
                  <Mail size={24} className="text-accent-bronze" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 uppercase tracking-widest">{t({ en: 'Email', ar: 'البريد الإلكتروني' })}</h4>
                  <p className="text-white/80">info@abusweilem.com</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 rtl:space-x-reverse">
                <div className="bg-white/10 p-3 rounded-lg">
                  <Clock size={24} className="text-accent-bronze" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 uppercase tracking-widest">{t({ en: 'Business Hours', ar: 'ساعات العمل' })}</h4>
                  <p className="text-white/80">
                    {t({ en: 'Sun - Thu: 9:00 AM - 5:00 PM', ar: 'الأحد - الخميس: 9 صباحاً - 5 مساءً' })}<br />
                    {t({ en: 'Sat: 10:00 AM - 2:00 PM', ar: 'السبت: 10 صباحاً - 2 مساءً' })}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-accent-bronze/10 p-8 rounded-3xl border border-accent-bronze/20 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-brand-burgundy mb-1">{t({ en: 'Quick WhatsApp', ar: 'واتساب سريع' })}</h4>
                <p className="text-sm text-text-muted">{t({ en: 'Chat with our legal team', ar: 'تحدث مع فريقنا القانوني' })}</p>
              </div>
              <a href="#" className="bg-emerald-600 text-white p-4 rounded-full shadow-lg hover:bg-emerald-700 transition-all">
                <MessageCircle size={24} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
