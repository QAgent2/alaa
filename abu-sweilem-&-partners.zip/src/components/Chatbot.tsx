import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../LanguageContext';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, User, Loader2 } from 'lucide-react';
import { getLegalAssistantResponse } from '../services/gemini';
import ReactMarkdown from 'react-markdown';
import { cn } from '../utils';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export const Chatbot = () => {
  const { t, lang, isRtl } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        {
          role: 'assistant',
          content: t({
            en: "Welcome to Abu Sweilem & Partners. How can I assist you with your legal inquiries today?",
            ar: "مرحباً بكم في مكتب أبو سويلم وشركاؤه. كيف يمكنني مساعدتكم في استفساراتكم القانونية اليوم؟"
          })
        }
      ]);
    }
  }, [isOpen, t]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    const response = await getLegalAssistantResponse(userMessage, lang);
    
    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col items-end">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className={cn(
              "mb-4 w-[350px] md:w-[400px] h-[500px] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-brand-burgundy/10",
              isRtl ? "font-sans-ar" : "font-sans-en"
            )}
          >
            {/* Header */}
            <div className="bg-brand-burgundy p-4 flex items-center justify-between text-white">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                  <Bot size={24} className="text-accent-bronze" />
                </div>
                <div>
                  <h4 className="font-bold text-sm leading-tight">
                    {t({ en: 'Legal Assistant', ar: 'المساعد القانوني' })}
                  </h4>
                  <span className="text-[10px] text-accent-bronze uppercase tracking-widest font-bold">
                    {t({ en: 'AI Powered', ar: 'مدعوم بالذكاء الاصطناعي' })}
                  </span>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-1 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-cream-soft/30">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "flex",
                    msg.role === 'user' ? "justify-end" : "justify-start"
                  )}
                >
                  <div
                    className={cn(
                      "max-w-[80%] p-3 rounded-2xl text-sm shadow-sm",
                      msg.role === 'user'
                        ? "bg-brand-burgundy text-white rounded-tr-none"
                        : "bg-white text-text-primary border border-brand-burgundy/5 rounded-tl-none"
                    )}
                  >
                    <div className="prose prose-sm max-w-none prose-p:leading-relaxed prose-p:my-1">
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white p-3 rounded-2xl rounded-tl-none border border-brand-burgundy/5 shadow-sm">
                    <Loader2 size={18} className="animate-spin text-accent-bronze" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-brand-burgundy/5">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder={t({ en: 'Type your message...', ar: 'اكتب رسالتك هنا...' })}
                  className="flex-1 bg-cream-soft/50 border-0 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-brand-burgundy outline-none"
                />
                <button
                  onClick={handleSend}
                  disabled={isLoading || !input.trim()}
                  className="bg-brand-burgundy text-white p-2 rounded-xl hover:bg-accent-bronze transition-all disabled:opacity-50"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-brand-burgundy text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-accent-bronze transition-all"
      >
        <MessageSquare size={28} />
      </motion.button>
    </div>
  );
};
