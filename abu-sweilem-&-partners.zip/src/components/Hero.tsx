import React from 'react';
import { useLanguage } from '../LanguageContext';
import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';

export const Hero = () => {
  const { t } = useLanguage();

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden bg-cream-soft">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1505664194779-8beaceb93744?auto=format&fit=crop&q=80&w=2000" 
          alt="Legal Background" 
          className="absolute inset-0 w-full h-full object-cover opacity-10"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-hero opacity-5" />
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#502223" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h1 className="flex flex-col items-center mb-6">
            <span className="font-serif-en text-5xl md:text-7xl lg:text-9xl font-black text-brand-burgundy tracking-tighter leading-none">
              ABU SWEILEM
            </span>
            <span className="font-serif-ar text-4xl md:text-6xl lg:text-8xl font-black text-brand-burgundy leading-none mt-2">
              أبو سويلم وشركاؤه
            </span>
          </h1>

          <div className="w-24 h-1 bg-accent-bronze mx-auto mb-8" />

          <h2 className="font-display-en italic text-2xl md:text-4xl text-text-secondary mb-4">
            {t({ en: 'Attorneys & Legal Consultants', ar: 'محامون ومستشارون' })}
          </h2>

          <p className="max-w-2xl mx-auto font-body text-lg md:text-xl text-text-muted mb-12 leading-relaxed">
            {t({
              en: 'Distinguished Legal Excellence Since 1998. Comprehensive Legal Solutions with Strategic Vision.',
              ar: 'تميز قانوني منذ عام 1998. حلول قانونية شاملة برؤية استراتيجية.'
            })}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#contact"
              className="w-full sm:w-auto bg-brand-burgundy text-white px-10 py-4 rounded-full text-lg font-bold shadow-2xl hover:bg-burgundy-dark transition-all"
            >
              {t({ en: 'Book Consultation Now', ar: 'احجز استشارة الآن' })}
            </motion.a>
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#practice-areas"
              className="w-full sm:w-auto border-2 border-brand-burgundy text-brand-burgundy px-10 py-4 rounded-full text-lg font-bold hover:bg-brand-burgundy hover:text-white transition-all"
            >
              {t({ en: 'Explore Our Expertise', ar: 'استكشف خبراتنا' })}
            </motion.a>
          </div>
        </motion.div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
        >
          <div className="flex flex-col items-center">
            <span className="text-accent-bronze font-bold text-2xl">25+</span>
            <span className="text-xs uppercase tracking-widest text-text-muted">
              {t({ en: 'Years Experience', ar: 'عاماً من الخبرة' })}
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-accent-bronze font-bold text-2xl">3000+</span>
            <span className="text-xs uppercase tracking-widest text-text-muted">
              {t({ en: 'Cases Handled', ar: 'قضية منجزة' })}
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-accent-bronze font-bold text-2xl">100%</span>
            <span className="text-xs uppercase tracking-widest text-text-muted">
              {t({ en: 'Client Satisfaction', ar: 'رضا العملاء' })}
            </span>
          </div>
        </motion.div>
      </div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-accent-bronze cursor-pointer"
        onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
      >
        <ChevronDown size={32} />
      </motion.div>
    </section>
  );
};
