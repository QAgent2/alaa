import React from 'react';
import { useLanguage } from '../LanguageContext';
import { motion } from 'motion/react';

export const About = () => {
  const { t } = useLanguage();

  return (
    <section id="about" className="py-24 bg-cream-soft overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1000"
                alt="Law Firm Office"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 bg-brand-burgundy p-10 rounded-3xl shadow-2xl hidden md:block">
              <div className="text-white text-center">
                <span className="block text-5xl font-black mb-2">25</span>
                <span className="block text-xs uppercase tracking-widest font-bold text-accent-bronze">
                  {t({ en: 'Years of Excellence', ar: 'عاماً من التميز' })}
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div>
              <h2 className="font-serif-en text-4xl md:text-5xl font-bold text-brand-burgundy mb-4">
                {t({ en: 'ABOUT ABU SWEILEM & PARTNERS', ar: 'عن مكتب أبو سويلم وشركاؤه' })}
              </h2>
              <div className="w-20 h-1 bg-accent-bronze" />
            </div>

            <p className="text-xl md:text-2xl text-text-primary font-medium leading-relaxed">
              {t({
                en: '"Abu Sweilem & Partners stands as a beacon of legal excellence, combining decades of expertise with modern strategic thinking."',
                ar: '"يقف مكتب أبو سويلم وشركاؤه كمنارة للتميز القانوني، يجمع بين عقود من الخبرة والتفكير الاستراتيجي الحديث."'
              })}
            </p>

            <p className="text-text-secondary text-lg leading-relaxed">
              {t({
                en: 'We are not just legal representatives—we are trusted advisors committed to protecting your interests and achieving optimal outcomes. Our firm has built a reputation for integrity, precision, and unwavering dedication to justice.',
                ar: 'نحن لسنا مجرد ممثلين قانونيين—بل مستشارون موثوقون ملتزمون بحماية مصالحكم وتحقيق النتائج المثلى. لقد بنى مكتبنا سمعة طيبة في النزاهة والدقة والتفاني الذي لا يتزعزع في تحقيق العدالة.'
              })}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
              {[
                { en: 'Proven Expertise', ar: 'الخبرة المثبتة' },
                { en: 'Strategic Approach', ar: 'نهج استراتيجي' },
                { en: 'Client Partnership', ar: 'شراكة مع العميل' },
                { en: 'Bilingual Excellence', ar: 'تميز ثنائي اللغة' }
              ].map((item, i) => (
                <div key={i} className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className="w-10 h-10 bg-accent-bronze/10 rounded-full flex items-center justify-center text-accent-bronze">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  </div>
                  <span className="font-bold text-brand-burgundy">{t(item)}</span>
                </div>
              ))}
            </div>

            <div className="pt-8">
              <a href="#contact" className="inline-block bg-brand-burgundy text-white px-8 py-4 rounded-full font-bold hover:bg-accent-bronze transition-all shadow-lg">
                {t({ en: 'Learn More About Us', ar: 'تعرف أكثر علينا' })}
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
