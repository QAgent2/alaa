import React, { useState, useEffect } from 'react';
import { useLanguage } from '../LanguageContext';
import { NAV_ITEMS } from '../constants';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Globe } from 'lucide-react';
import { cn } from '../utils';

export const Navbar = () => {
  const { lang, setLang, t, isRtl } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4',
        isScrolled ? 'bg-cream-soft/90 backdrop-blur-md shadow-md' : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <div className="flex flex-col">
          <span className="font-serif-en text-xl md:text-2xl font-bold text-brand-burgundy leading-tight tracking-tight">
            ABU SWEILEM & PARTNERS
          </span>
          <span className="font-serif-ar text-lg md:text-xl font-bold text-brand-burgundy leading-tight">
            أبو سويلم وشركاؤه
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center space-x-8 rtl:space-x-reverse">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="font-body text-sm font-medium text-brand-burgundy hover:text-accent-bronze transition-colors"
            >
              {t(item.label)}
            </a>
          ))}
          
          <button
            onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
            className="flex items-center space-x-2 rtl:space-x-reverse px-3 py-1 border border-brand-burgundy/20 rounded-full hover:bg-brand-burgundy hover:text-white transition-all"
          >
            <Globe size={16} />
            <span className="text-xs font-bold uppercase">{lang === 'en' ? 'AR' : 'EN'}</span>
          </button>

          <a
            href="#contact"
            className="bg-brand-burgundy text-white px-6 py-2 rounded-full text-sm font-semibold hover:bg-accent-bronze transition-all shadow-lg"
          >
            {t({ en: 'Book Consultation', ar: 'احجز استشارة' })}
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          className="lg:hidden text-brand-burgundy"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-cream-soft shadow-2xl lg:hidden border-t border-brand-burgundy/10"
          >
            <div className="flex flex-col p-6 space-y-4">
              {NAV_ITEMS.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="font-body text-lg font-medium text-brand-burgundy border-b border-brand-burgundy/5 pb-2"
                >
                  {t(item.label)}
                </a>
              ))}
              <div className="flex items-center justify-between pt-4">
                <button
                  onClick={() => {
                    setLang(lang === 'en' ? 'ar' : 'en');
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center space-x-2 rtl:space-x-reverse text-brand-burgundy font-bold"
                >
                  <Globe size={20} />
                  <span>{lang === 'en' ? 'العربية' : 'English'}</span>
                </button>
                <a
                  href="#contact"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="bg-brand-burgundy text-white px-6 py-2 rounded-full text-sm font-semibold"
                >
                  {t({ en: 'Book Now', ar: 'احجز الآن' })}
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
