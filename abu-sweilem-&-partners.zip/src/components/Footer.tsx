import React from 'react';
import { useLanguage } from '../LanguageContext';
import { motion } from 'motion/react';
import { NAV_ITEMS } from '../constants';
import { Linkedin, Twitter, Facebook, Instagram } from 'lucide-react';

export const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-brand-burgundy text-cream-soft py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex flex-col">
              <span className="font-serif-en text-2xl font-bold tracking-tight">ABU SWEILEM & PARTNERS</span>
              <span className="font-serif-ar text-xl font-bold">أبو سويلم وشركاؤه</span>
            </div>
            <p className="text-cream-soft/70 leading-relaxed">
              {t({
                en: 'Excellence in Legal Representation. A beacon of legal authority and strategic vision since 1998.',
                ar: 'التميز في التمثيل القانوني. منارة للسلطة القانونية والرؤية الاستراتيجية منذ عام 1998.'
              })}
            </p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              {[Linkedin, Twitter, Facebook, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-accent-bronze transition-all">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-bold text-lg mb-8 uppercase tracking-widest text-accent-bronze">
              {t({ en: 'Quick Links', ar: 'روابط سريعة' })}
            </h4>
            <ul className="space-y-4">
              {NAV_ITEMS.map((item) => (
                <li key={item.href}>
                  <a href={item.href} className="text-cream-soft/70 hover:text-white transition-colors">
                    {t(item.label)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-8 uppercase tracking-widest text-accent-bronze">
              {t({ en: 'Services', ar: 'الخدمات' })}
            </h4>
            <ul className="space-y-4">
              <li><a href="#practice-areas" className="text-cream-soft/70 hover:text-white transition-colors">{t({ en: 'Civil Law', ar: 'القانون المدني' })}</a></li>
              <li><a href="#practice-areas" className="text-cream-soft/70 hover:text-white transition-colors">{t({ en: 'Corporate Law', ar: 'قانون الشركات' })}</a></li>
              <li><a href="#practice-areas" className="text-cream-soft/70 hover:text-white transition-colors">{t({ en: 'Criminal Defense', ar: 'الدفاع الجنائي' })}</a></li>
              <li><a href="#practice-areas" className="text-cream-soft/70 hover:text-white transition-colors">{t({ en: 'Arbitration', ar: 'التحكيم' })}</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-8 uppercase tracking-widest text-accent-bronze">
              {t({ en: 'Contact', ar: 'اتصل بنا' })}
            </h4>
            <ul className="space-y-4 text-cream-soft/70">
              <li>+962 6 123 4567</li>
              <li>info@abusweilem.com</li>
              <li className="pt-4">
                <a href="#contact" className="inline-block bg-accent-bronze text-brand-burgundy px-6 py-2 rounded-full font-bold hover:bg-white transition-all">
                  {t({ en: 'Book Now', ar: 'احجز الآن' })}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-cream-soft/50">
          <p>© 2026 Abu Sweilem & Partners. {t({ en: 'All Rights Reserved.', ar: 'جميع الحقوق محفوظة.' })}</p>
          <div className="flex space-x-6 rtl:space-x-reverse">
            <a href="#" className="hover:text-white">{t({ en: 'Privacy Policy', ar: 'سياسة الخصوصية' })}</a>
            <a href="#" className="hover:text-white">{t({ en: 'Terms of Service', ar: 'شروط الخدمة' })}</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
