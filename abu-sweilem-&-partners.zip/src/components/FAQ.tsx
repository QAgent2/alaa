import React, { useState } from 'react';
import { useLanguage } from '../LanguageContext';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus } from 'lucide-react';
import { FAQS } from '../constants';

import { cn } from '../utils';

export const FAQ = () => {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-cream-warm">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif-en text-4xl md:text-5xl font-bold text-brand-burgundy mb-4">
            {t({ en: 'FREQUENTLY ASKED QUESTIONS', ar: 'الأسئلة الشائعة' })}
          </h2>
          <div className="w-20 h-1 bg-accent-bronze mx-auto" />
        </div>

        <div className="space-y-4">
          {FAQS.map((faq, index) => (
            <div
              key={index}
              className="border-b border-accent-bronze/20 last:border-0"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full py-6 flex items-center justify-between text-left rtl:text-right group"
              >
                <span className={cn(
                  "font-serif-en text-xl md:text-2xl font-bold transition-colors",
                  openIndex === index ? "text-accent-bronze" : "text-brand-burgundy group-hover:text-accent-bronze"
                )}>
                  {t(faq.question)}
                </span>
                <div className="text-accent-bronze ml-4 rtl:ml-0 rtl:mr-4">
                  {openIndex === index ? <Minus size={24} /> : <Plus size={24} />}
                </div>
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="pb-8 text-text-secondary text-lg leading-relaxed">
                      {t(faq.answer)}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
