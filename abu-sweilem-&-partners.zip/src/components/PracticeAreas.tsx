import React from 'react';
import { useLanguage } from '../LanguageContext';
import { motion } from 'motion/react';
import { Scale, Building2, Handshake, ShieldAlert, FileText, Briefcase } from 'lucide-react';
import { PRACTICE_AREAS } from '../constants';

const IconMap: Record<string, any> = {
  Scale,
  Building2,
  Handshake,
  ShieldAlert,
  FileText,
  Briefcase,
};

export const PracticeAreas = () => {
  const { t, lang } = useLanguage();

  return (
    <section id="practice-areas" className="py-24 bg-cream-warm">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-serif-en text-4xl md:text-5xl font-bold text-brand-burgundy mb-4"
          >
            {t({ en: 'OUR PRACTICE AREAS', ar: 'اختصاصاتنا القانونية' })}
          </motion.h2>
          <div className="w-20 h-1 bg-accent-bronze mx-auto mb-6" />
          <p className="max-w-2xl mx-auto text-text-secondary text-lg">
            {t({
              en: 'Comprehensive legal solutions across all areas of law, delivered with strategic precision and unwavering dedication.',
              ar: 'حلول قانونية شاملة عبر جميع مجالات القانون، تُقدم بدقة استراتيجية وتفانٍ لا يتزعزع.'
            })}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PRACTICE_AREAS.map((area, index) => {
            const Icon = IconMap[area.icon];
            return (
              <motion.div
                key={area.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-white p-10 rounded-2xl shadow-sm hover:shadow-xl transition-all border border-transparent hover:border-accent-bronze/30 group"
              >
                <div className="w-16 h-16 bg-cream-soft rounded-xl flex items-center justify-center mb-6 text-accent-bronze group-hover:bg-brand-burgundy group-hover:text-white transition-colors">
                  <Icon size={32} />
                </div>
                <h3 className="font-serif-en text-2xl font-bold text-brand-burgundy mb-4">
                  {t(area.title)}
                </h3>
                <p className="text-text-secondary mb-6 leading-relaxed">
                  {t(area.description)}
                </p>
                <ul className="space-y-2">
                  {area.keyServices[lang].map((service, idx) => (
                    <li key={idx} className="flex items-center text-sm text-text-muted">
                      <div className="w-1.5 h-1.5 bg-accent-bronze rounded-full mr-3 rtl:mr-0 rtl:ml-3" />
                      {service}
                    </li>
                  ))}
                </ul>
                <div className="mt-8 pt-6 border-t border-cream-warm">
                  <a href="#contact" className="text-accent-bronze font-bold text-sm hover:text-brand-burgundy transition-colors flex items-center">
                    {t({ en: 'Learn More', ar: 'تعرف على المزيد' })}
                    <span className="ml-2 rtl:ml-0 rtl:mr-2">→</span>
                  </a>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
