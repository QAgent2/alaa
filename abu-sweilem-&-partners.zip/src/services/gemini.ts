import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const getLegalAssistantResponse = async (message: string, lang: 'en' | 'ar') => {
  const systemInstruction = lang === 'en' 
    ? "You are a professional legal assistant for Abu Sweilem & Partners Law Firm. Your tone is formal, authoritative, and helpful. You provide general legal information but always state that this is not formal legal advice and suggest booking a consultation for specific cases. You speak English."
    : "أنت مساعد قانوني محترف لمكتب أبو سويلم وشركاؤه للمحاماة. نبرتك رسمية، موثوقة، ومفيدة. أنت تقدم معلومات قانونية عامة ولكنك تذكر دائماً أن هذا ليس استشارة قانونية رسمية وتقترح حجز استشارة للحالات المحددة. أنت تتحدث العربية.";

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: message,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return response.text || (lang === 'en' ? "I'm sorry, I couldn't process that request." : "عذراً، لم أتمكن من معالجة هذا الطلب.");
  } catch (error) {
    console.error("Gemini API Error:", error);
    return lang === 'en' ? "An error occurred. Please try again later." : "حدث خطأ. يرجى المحاولة مرة أخرى لاحقاً.";
  }
};
