
export type Language = 'en' | 'ar';

export interface NavItem {
  label: { en: string; ar: string };
  href: string;
}

export interface PracticeArea {
  id: string;
  title: { en: string; ar: string };
  description: { en: string; ar: string };
  icon: string;
  keyServices: { en: string[]; ar: string[] };
}

export interface FAQItem {
  question: { en: string; ar: string };
  answer: { en: string; ar: string };
}
