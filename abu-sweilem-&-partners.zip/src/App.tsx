import React from 'react';
import { LanguageProvider } from './LanguageContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { PracticeAreas } from './components/PracticeAreas';
import { FAQ } from './components/FAQ';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { Chatbot } from './components/Chatbot';
import { motion } from 'motion/react';

export default function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen selection:bg-accent-bronze selection:text-brand-burgundy">
        <Navbar />
        <main>
          <Hero />
          <About />
          <PracticeAreas />
          
          {/* Stats Section */}
          <section className="py-24 bg-brand-burgundy text-cream-soft relative overflow-hidden">
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#c9b398_1px,transparent_1px)] [background-size:40px_40px]" />
            </div>
            <div className="max-w-7xl mx-auto px-6 relative z-10">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
                {[
                  { val: '25+', label: { en: 'Years Experience', ar: 'عاماً من الخبرة' } },
                  { val: '3000+', label: { en: 'Cases Handled', ar: 'قضية منجزة' } },
                  { val: '95%', label: { en: 'Success Rate', ar: 'معدل النجاح' } },
                  { val: '100%', label: { en: 'Client Satisfaction', ar: 'رضا العملاء' } }
                ].map((stat, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <span className="block text-5xl md:text-7xl font-black text-accent-bronze mb-2">{stat.val}</span>
                    <span className="block text-sm md:text-base uppercase tracking-widest font-bold opacity-70">
                      {stat.label.en} <br /> {stat.label.ar}
                    </span>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          <FAQ />
          <Contact />
        </main>
        <Footer />
        <Chatbot />
      </div>
    </LanguageProvider>
  );
}
